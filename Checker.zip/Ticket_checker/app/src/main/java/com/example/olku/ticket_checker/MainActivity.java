package com.example.olku.ticket_checker;

import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static java.lang.Math.round;

public class MainActivity extends AppCompatActivity {

    TextToSpeech t1;
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference dref,  dref2, dref3, dref4;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    Information info;

    Calendar calendar;
    SimpleDateFormat simpleDateFormat;
    String Date;
    String status;
    Boolean sts = false;
    Boolean paySts = true;
    String date1;
    private DecimalFormat df2;
    //private LatLng driverLatLng;
    private DatabaseReference driverLocationRef, userLocationRef;
    private ValueEventListener driverLocationRefListener, userLoactionListener;
    double locationLat;
    double locationLng;
    String key;
    double U_lat, U_lng;
    String acc_tk,balance;
    double basefare = 1.8;
    int a_tk;
    String say = "welcome";
    int c;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        process();


    }

    public void process() {


        final String mail = getIntent().getStringExtra("result");

        df2 = new DecimalFormat( ".##" );

        info = new Information();
        listView = (ListView) findViewById(R.id.listview);


        dref2 =  FirebaseDatabase.getInstance().getReference().child("Users");
        dref2.orderByChild("email")
                .equalTo(mail)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                        }
                        acc_tk = dataSnapshot.child(key).child("Amount").getValue().toString();
                        a_tk = Integer.parseInt(acc_tk);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });




        final Query query = FirebaseDatabase.getInstance().getReference("User_Package_info")
                .orderByChild("email")
                .equalTo(mail);


        list = new ArrayList<>();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, list);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int count = 0;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    info = ds.getValue(Information.class);

                    if(count==0){
                      list.add(info.getEmail().toString());
                       count++;
                    }

                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

                    Date strDate = null;
                    try {
                        strDate = sdf.parse(info.getExpire_date());
                    } catch (ParseException e) {

                    }

                    if (System.currentTimeMillis() < strDate.getTime()) {
                        //catalog_outdated = 1;
                        list.add("Package name: " + info.getPackage().toString());
                        list.add("Package Validity: "  + info.getExpire_date().toString());
                        sts = true;


                   driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversAvailable").child("driver1").child("l");

                    driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists()){
                                    List<Object> map = (List<Object>) dataSnapshot.getValue();


                                    if(map.get(0) != null){
                                        locationLat = Double.parseDouble(map.get(0).toString());
                                    }
                                    if(map.get(1) != null){
                                        locationLng = Double.parseDouble(map.get(1).toString());
                                    }


                                    Query query2 = FirebaseDatabase.getInstance().getReference("Bus1")
                                            .orderByChild("email")
                                            .equalTo(mail);
                                query2.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.getValue() != null){
                                            ///


                                            ////
                                            say = "Thank you for the trip";
                                            speak(say);

                                            //History();

                                            dref = FirebaseDatabase.getInstance().getReference().child("Users");

                                            Query query3 = FirebaseDatabase.getInstance().getReference("Bus1")
                                                    .orderByChild("email")
                                                    .equalTo(mail);
                                            query3.addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {
                                                    for (DataSnapshot ds: dataSnapshot.getChildren()){
                                                        ds.getRef().removeValue();


                                                    }
                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            });

                                        }
                                        else {

                                            DatabaseReference dref1 = FirebaseDatabase.getInstance().getReference().child("Bus1");
                                            String id = dref1.push().getKey();
                                            dref1.child(id).child("email").setValue(mail);
                                            dref1.child(id).child("lat").setValue(locationLat);
                                            dref1.child( id ).child( "lng" ).setValue( locationLng );
                                            say = "welcome User, On Package";
                                            speak(say);

                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });


                                 }

                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                            }
                        });

                    }
                    else {


                    }

                }



                if( !sts && a_tk>=40 ){


                    //Toast.makeText(getApplicationContext(), "No package", Toast.LENGTH_LONG).show();
                    list.add("no package");

                    driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversAvailable").child("driver1").child("l");
                    driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                List<Object> map = (List<Object>) dataSnapshot.getValue();

                                //   mReqst.setText("Driver Found");
                                if(map.get(0) != null){
                                    locationLat = Double.parseDouble(map.get(0).toString());
                                }
                                if(map.get(1) != null){
                                    locationLng = Double.parseDouble(map.get(1).toString());
                                }


                                Query query2 = FirebaseDatabase.getInstance().getReference("Bus1")
                                        .orderByChild("email")
                                        .equalTo(mail);
                                query2.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.getValue() != null){
                                            say = "Fare taken, thank you";
                                            speak(say);
                                            dref2 =  FirebaseDatabase.getInstance().getReference().child("Users");
                                            dref2.orderByChild("email")
                                                    .equalTo(mail)
                                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                                            for (DataSnapshot child : dataSnapshot.getChildren()) {
                                                                key = child.getKey();
                                                            }
                                                            acc_tk = dataSnapshot.child(key).child("Amount").getValue().toString();





                                        driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversAvailable").child("driver1").child("l");
                                        driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                if(dataSnapshot.exists()){
                                                    List<Object> map = (List<Object>) dataSnapshot.getValue();

                                                    if(map.get(0) != null){
                                                        locationLat = Double.parseDouble(map.get(0).toString());
                                                    }
                                                    if(map.get(1) != null){
                                                        locationLng = Double.parseDouble(map.get(1).toString());
                                                    }
                                                }
                                            }

                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });


        dref3 = FirebaseDatabase.getInstance().getReference().child("Bus1");
        dref3.orderByChild("email")
                .equalTo(mail)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                        }

                        U_lat = Double.parseDouble(dataSnapshot.child(key).child("lat").getValue().toString());
                        U_lng = Double.parseDouble(dataSnapshot.child(key).child("lng").getValue().toString());


                        double distances = distances( U_lat, U_lng, locationLat, locationLng);
                        Double fare = basefare*distances;
                        Integer a_fare = Integer.valueOf((int) Math.round(fare));
                        int tk = Integer.parseInt(acc_tk);


                        balance = Integer.toString(tk - a_fare);

                        String dist = df2.format(distances);

                        Toast.makeText(getApplicationContext(), " dis: " + dist + " fare:  " + a_fare ,  Toast.LENGTH_SHORT).show();

                        dref2 =  FirebaseDatabase.getInstance().getReference().child("Users");
                        dref2.orderByChild("email")
                                .equalTo(mail)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                                            key = child.getKey();
                                        }
                                        dref2.child(key).child("Amount").setValue(balance);

                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });




                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                    /////Now Distance..

                    //double distances = distances( U_lat, U_lng, locationLat, locationLng);


                                                        }

                                                        @Override
                                                        public void onCancelled(DatabaseError databaseError) {

                                                        }
                                                    });

                                            ///History();

                                            Query query3 = FirebaseDatabase.getInstance().getReference("Bus1")
                                                    .orderByChild("email")
                                                    .equalTo(mail);
                                            query3.addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {
                                                    for (DataSnapshot ds: dataSnapshot.getChildren()){

                                                        ds.getRef().removeValue();



                                                    }
                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            });

                                        }
                                        else {
                                            DatabaseReference dref1 = FirebaseDatabase.getInstance().getReference().child("Bus1");
                                            String id = dref1.push().getKey();
                                            dref1.child(id).child("email").setValue(mail);
                                            dref1.child(id).child("lat").setValue(locationLat);
                                            dref1.child( id ).child( "lng" ).setValue( locationLng );
                                            say = "Welcome eligable User";
                                            speak(say);
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });




                            }

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });


                }
                else if(!sts && a_tk < 40){
                    say = "Not eligable, sorry";
                    speak(say);
                    list.add("Not Eligable");
                    //Toast.makeText(getApplicationContext(), "Not Eligable", Toast.LENGTH_SHORT).show();
                }


                listView.setAdapter(adapter);
                //speak(say);



            }

         ///}
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });


        ///sesh

        //}


        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i == TextToSpeech.SUCCESS) {
                    int result = t1.setLanguage(Locale.UK);
                    if ((result == TextToSpeech.LANG_MISSING_DATA) || (result == TextToSpeech.LANG_NOT_SUPPORTED)) {
                        Toast.makeText(getApplicationContext(), "Not support", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(getApplicationContext(), "not working", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private double distances(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;
        // double km = dist/1;

        return dist; // output distance, in MILES
    }

    public void speak(String said){


        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
           Toast.makeText(getApplicationContext(), " " + said, Toast.LENGTH_SHORT).show();
            t1.speak(said, TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    @Override
    protected void onDestroy() {
        if(t1 != null){
            t1.stop();
            t1.shutdown();
        }

        super.onDestroy();
    }

    public void History(){

        Geocoder myLocation = new Geocoder(MainActivity.this, Locale.getDefault());
        List<Address> myList = null;
        List<Address> myList1 = null;

           driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversAvailable").child("driver1").child("l");
                                        driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                if(dataSnapshot.exists()){
                                                    List<Object> map = (List<Object>) dataSnapshot.getValue();

                                                    if(map.get(0) != null){
                                                        locationLat = Double.parseDouble(map.get(0).toString());
                                                    }
                                                    if(map.get(1) != null){
                                                        locationLng = Double.parseDouble(map.get(1).toString());
                                                    }
                                                }
                                            }

                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });


             String mail = "saif@gmail.com";

             dref3 = FirebaseDatabase.getInstance().getReference().child("Bus1");
            dref3.orderByChild("email")
                .equalTo(mail)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                        }

                        U_lat = Double.parseDouble(dataSnapshot.child(key).child("lat").getValue().toString());
                        U_lng = Double.parseDouble(dataSnapshot.child(key).child("lng").getValue().toString());

                    }
                      @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


              try {
                            myList = myLocation.getFromLocation(locationLat,locationLng, 1);
                            myList1 = myLocation.getFromLocation( U_lat, U_lng, 1 );
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


        Address address = (Address) myList.get(0);
        String addressStr = "";
        addressStr += address.getAddressLine(0);

        Address address1 = (Address) myList1.get(0);
        String addressStr1 = "";
        addressStr1 += address1.getAddressLine(0);


        DatabaseReference dref1 = FirebaseDatabase.getInstance().getReference().child("History");

        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Calendar cal = Calendar.getInstance();

                          Toast.makeText( getApplicationContext(), ""  + dateFormat.format(cal.getTime()), Toast.LENGTH_SHORT ).show();
                         Toast.makeText( getApplicationContext(), " " + addressStr, Toast.LENGTH_LONG ).show();
                        Toast.makeText( getApplicationContext(), " " + addressStr1, Toast.LENGTH_LONG ).show();
                        Toast.makeText( getApplicationContext(), "" + getIntent().getExtras().getString("Email") , Toast.LENGTH_SHORT ).show();


}
}


