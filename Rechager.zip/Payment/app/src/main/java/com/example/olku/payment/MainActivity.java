package com.example.olku.payment;

import android.content.DialogInterface;
import android.provider.ContactsContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatAutoCompleteTextView;
import android.support.v7.widget.AppCompatCheckBox;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.spark.submitbutton.SubmitButton;

import org.aviran.cookiebar2.CookieBar;
import org.aviran.cookiebar2.OnActionClickListener;

public class MainActivity extends AppCompatActivity {

    // private FirebaseAuth auth;

    private AppCompatAutoCompleteTextView autoTextView;
    private AppCompatAutoCompleteTextView autoTextViewCustom;


    private SubmitButton btnRecharge;

    private EditText Email, Amount, PinCode;
    FirebaseDatabase database;
    DatabaseReference dref;
    private CheckBox checkbox;

    payment pay;

    String mail, amount, pin, key, acc_tk, phone;

    String P = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkbox = (CheckBox) findViewById(R.id.Checkbox);
        btnRecharge = (SubmitButton) findViewById(R.id.btn_recharge);
        Email = (EditText) findViewById(R.id.add);
        Amount = (EditText) findViewById(R.id.amount);
        PinCode = (EditText) findViewById(R.id.Pin_code);

       /* mail = Email.getText().toString();
        amount = Amount.getText().toString();
        pin = PinCode.getText().toString();
*/

        // boolean isChecked = false;
         checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                 if(!isChecked){
                     PinCode.setTransformationMethod(PasswordTransformationMethod.getInstance());
                 }
             else {
                     PinCode.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                 }
         }

    });

        mail = Email.getText().toString();
        amount = Amount.getText().toString();
        pin = PinCode.getText().toString();

        mail = mail.trim();
        amount = amount.trim();
        pin = pin.trim();

        pay = new payment();


        btnRecharge.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                // Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
                //payment pay = new payment();
                if (Email.getText().toString().trim().length() > 0
                        && Amount.getText().toString().trim().length() > 0
                        && PinCode.getText().toString().trim().length() > 0) {


                Query query = FirebaseDatabase.getInstance().getReference("Recharger").orderByChild("Pin")
                        .equalTo(PinCode.getText().toString());  ///thik korte hobe query


                query.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            pay = child.getValue(payment.class);
                        }
                      //  Toast.makeText(getApplicationContext(), "pin :" + pay.getPin() + "g: " + PinCode.getText(), Toast.LENGTH_LONG).show();
                        if (dataSnapshot.exists()) {

                        Query query1 = FirebaseDatabase.getInstance().getReference("Users").orderByChild("phone")
                                .equalTo(Email.getText().toString());

                            Recharge(mail, amount, pin);


                        } else {
                           // Toast.makeText(getApplicationContext(), "Not matched", Toast.LENGTH_LONG).show();

                           /* AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("Important");
                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            });
                            builder.setMessage("Pin Code not matched");
                            AlertDialog alert = builder.create();
                            alert.show();*/

                            CookieBar.build(MainActivity.this)
                                    .setTitle("SORRY")
                                    .setDuration(10000)
                                    .setIcon(R.drawable.error)
                                    .setMessage("Pin Code not matched")
                                    .setAction("Ok", new OnActionClickListener() {
                                        @Override
                                        public void onClick() {
                                        }
                                    })
                                    .show();



                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
            else {
                    //Toast.makeText(getApplicationContext(), "Please insert all the field value", Toast.LENGTH_LONG).show();

                 /*   AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Important");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    builder.setMessage("Please Insert all the Field ");
                    AlertDialog alert = builder.create();
                    alert.show();
                    */

                    CookieBar.build(MainActivity.this)
                            .setTitle("Important")
                            .setDuration(10000)
                            .setIcon(R.drawable.ic_announcement_black_24dp)
                            .setMessage("Please Insert All the Fields")
                            .setAction("Ok", new OnActionClickListener() {
                                @Override
                                public void onClick() {
                                }
                            })
                            .show();



                }

            }   //done


        });   ///done


    }


    public void Recharge(String email, String amount, String pin) {

        dref = FirebaseDatabase.getInstance().getReference().child("Users");

        dref.orderByChild("phone")
                .equalTo(Email.getText().toString())
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child: dataSnapshot.getChildren()) {
                    key = child.getKey();
                   // Toast.makeText(getApplicationContext(),key , Toast.LENGTH_LONG).show();
                }
                if(key == null){
                   // Toast.makeText(getApplicationContext(),"email not matched", Toast.LENGTH_LONG).show();
                    //return;

                   /* AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Important");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    builder.setMessage("Phone number not valid");
                    AlertDialog alert = builder.create();
                    alert.show();*/

                    CookieBar.build(MainActivity.this)
                            .setTitle("Attention")
                            .setDuration(10000)
                            .setIcon(R.drawable.error)
                            .setMessage("Phone number not valid")
                            .setAction("Ok", new OnActionClickListener() {
                                @Override
                                public void onClick() {
                                }
                            })
                            .show();



                }
                else {
                    acc_tk = dataSnapshot.child(key).child("Amount").getValue().toString();
                    int tk = Integer.parseInt(acc_tk);
                    int add_tk = Integer.parseInt(Amount.getText().toString());
                    String balance = Integer.toString(tk + add_tk);
                    //  Toast.makeText(getApplicationContext(), "key: " + key + "mail: " + Email.getText().toString() + "amount:" + Amount.getText().toString() + "Pin:" + PinCode.getText().toString(), Toast.LENGTH_LONG).show();
                   // Toast.makeText(getApplicationContext(), "tk : " + acc_tk, Toast.LENGTH_LONG).show();
                    dref.child(key).child("Amount").setValue(balance);
                   // Toast.makeText(getApplicationContext(), "Recharged", Toast.LENGTH_LONG).show();

                /*    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Important");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    builder.setMessage("Account Recharged Successfully.");
                    AlertDialog alert = builder.create();
                    alert.show();

                    */

                    CookieBar.build(MainActivity.this)
                            .setTitle("Success!!")
                            .setDuration(10000)
                            .setIcon(R.drawable.done)
                            .setMessage("Account Recharged Successfully")
                            .setAction("Ok", new OnActionClickListener() {
                                @Override
                                public void onClick() {
                                }
                            })
                            .show();


                    PinCode.setText("");
                    Email.setText("");
                    Amount.setText("");

                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        //String acc_tk = dataSnapshot.child(key).child("Amount").getValue().toString();
      /*  int tk =  Integer.parseInt(acc_tk);
        int add_tk = Integer.parseInt(Amount.getText().toString());
        String balance = Integer.toString(tk + add_tk);
        //  Toast.makeText(getApplicationContext(), "key: " + key + "mail: " + Email.getText().toString() + "amount:" + Amount.getText().toString() + "Pin:" + PinCode.getText().toString(), Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(), "tk : " + acc_tk , Toast.LENGTH_LONG).show();
        dref.child(key).child("Amount").setValue(balance);
        Toast.makeText(getApplicationContext(), "Recharged", Toast.LENGTH_LONG).show();*/


    }


    public void displayAlertMessage(String message,  DialogInterface.OnClickListener listener)
    {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("Ok", listener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }


}